chrome.tabs.executeScript(null, {
    file: "/content_scripts/main.js"
  });