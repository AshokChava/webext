window.alert(window.location.href);
window.location.href="http://www.oracle.com";
